import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements'
import { SampleService } from '../services/sample.service';
import { AccordionComponent } from './accordion/accordion.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AccordionComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule
  ],
  providers: [SampleService],
  entryComponents: [AccordionComponent]
})
export class AppModule { 

  constructor(injector: Injector) {
    const acc = createCustomElement(AccordionComponent, { injector });
    customElements.define('custom-accordion',acc);
  }
  ngDoBootstrap() {}
}
