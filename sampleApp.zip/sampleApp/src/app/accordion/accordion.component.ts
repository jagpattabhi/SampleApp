import { Component, ViewEncapsulation, Input, ElementRef, ViewChildren, QueryList,AfterViewInit } from '@angular/core';
import { SampleService } from '../../services/sample.service'
@Component({
  selector: 'custom-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.css'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class AccordionComponent {
  @Input() icon = 'arrow';
  @ViewChildren('el') components: QueryList<AccordionComponent>;
  sampleData:Object[];
  constructor(private sample : SampleService) {
    this.sample.getJSON().subscribe(data => {
      console.log(data);
      this.sampleData = data;
  });
   }

  toggleHelper(index) {
    var elements = this.components._results;
    for(var i=0; i<elements.length; i++){
      if (i !== index)
      {
      elements[i].nativeElement.classList.remove("active");
      var panel = elements[i].nativeElement.nextElementSibling;
      panel.style.maxHeight = null;
      }
    }


    elements[index].nativeElement.classList.toggle("active");
    var panel = elements[index].nativeElement.nextElementSibling;
        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        }
  }
 
}
